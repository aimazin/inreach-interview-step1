import json
import os
import sys
import pandas as pd

from dump.CompanyReader import CompanyReader

company_reader = CompanyReader('{}/tests/resources/objects.csv'.format(os.path.dirname(os.path.abspath(__file__))))
companies=[]
for i in range(1,len(sys.argv)):
    company = company_reader.company(sys.argv[i])
    if company is not None:
        companies.append(company)
companies=pd.DataFrame(companies)[['name','relationships','funding_rounds']]
companies.columns=['company','people','funding_rounds']
print((companies.to_json(orient='records')[1:-1].replace('},{', '} {')))

       