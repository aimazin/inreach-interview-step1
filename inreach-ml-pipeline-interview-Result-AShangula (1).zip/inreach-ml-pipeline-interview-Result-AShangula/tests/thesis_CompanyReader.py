import os
import unittest 
import sys

from dump.CompanyReader import CompanyReader


class TestCompanyReader(unittest.TestCase):
    

    def setUp(self):
        self.__company_reader = CompanyReader('{}/tests/resources/objects.csv'.format(os.path.dirname(os.path.abspath(__file__))))

    def test_get_company(self):
        company = self.__company_reader.company('1')
        self.assertIsNotNone(company)
        self.assertEqual('c:1', company['id'])
        company2 = self.__company_reader.company('10')
        self.assertIsNotNone(company2)
        self.assertEqual('c:10', company2['id'])
        company3 = self.__company_reader.company('10')
        self.assertIsNotNone(company3)
        self.assertEqual('c:10', company3['id'])
        #print(company)

    def test_do_not_get_company(self):
        self.assertIsNone(self.__company_reader.company('213'))

if __name__=='__main__':
    unittest.main()
